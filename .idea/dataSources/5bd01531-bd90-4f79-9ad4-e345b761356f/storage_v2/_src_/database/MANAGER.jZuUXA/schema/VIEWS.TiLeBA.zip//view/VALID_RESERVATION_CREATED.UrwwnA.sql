CREATE FORCE VIEW VIEWS.VALID_RESERVATION_CREATED(ID, DESCRIPTION, WEIGTH, VALIDATE, R_ANNOUNCE_ID, DEPARTURE, ARRIVAL,
                                                  START_DATE, END_DATE, R_USER_ID, FIRST_NAME, LAST_NAME, USERNAME,
                                                  EMAIL, PHONE, GENDER) AS
SELECT R.ID,
       R.DESCRIPTION,
       R.WEIGTH,
       R.VALIDATE,
       A.ID AS R_ANNOUNCE_ID,
       A.DEPARTURE,
       A.ARRIVAL,
       A.START_DATE,
       A.END_DATE,
       U.ID AS R_USER_ID,
       U.FIRST_NAME,
       U.LAST_NAME,
       U.USERNAME,
       U.EMAIL,
       U.PHONE,
       U.GENDER
FROM PUBLIC.RESERVATION R
         INNER JOIN PUBLIC.ANNOUNCE A
                    ON 1 = 1
         INNER JOIN PUBLIC.USER U
                    ON 1 = 1
WHERE ((R.R_USER_ID = U.ID)
    AND (A.ID = R.R_ANNOUNCE_ID))
  AND ((R.STATUS = 'VALID')
    AND ((A.STATUS = 'VALID')
        AND ((R.CANCELLED IS FALSE)
            AND (A.CANCELLED IS FALSE))));

